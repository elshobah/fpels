<?php return array (
  'auth.install' => 'App\\Http\\Livewire\\Auth\\Install',
  'auth.login' => 'App\\Http\\Livewire\\Auth\\Login',
);