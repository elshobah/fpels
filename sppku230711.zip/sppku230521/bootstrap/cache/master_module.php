<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Master\\Providers\\MasterServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Master\\Providers\\MasterServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);