<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Setting\\Providers\\SettingServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Setting\\Providers\\SettingServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);