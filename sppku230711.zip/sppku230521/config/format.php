<?php

return [
    'path' => public_path('format')
];
