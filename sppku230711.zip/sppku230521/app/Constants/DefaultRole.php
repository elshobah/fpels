<?php

namespace App\Constants;

use App\Constants\Constants;

class DefaultRole extends Constants
{
    public static function labels(): array
    {
        return ['Super Admin'];
    }
}