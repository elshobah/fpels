require('./bootstrap');

/** get from stisla */
require('./scripts');