<?php

return [
	'setup' => 'Setup Your Application'
];