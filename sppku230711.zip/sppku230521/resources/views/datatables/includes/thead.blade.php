@if ($tableHeaderEnabled)
    <thead class="">
        @include('datatable::includes.columns')
    </thead>
@endif
