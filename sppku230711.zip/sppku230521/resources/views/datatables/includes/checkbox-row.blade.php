<input type="checkbox" wire:model="checkbox_values" style="cursor: pointer;" value="{{ $model->{$checkbox_attribute} }}" />
