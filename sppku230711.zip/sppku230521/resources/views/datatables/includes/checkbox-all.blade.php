<input type="checkbox" wire:model="checkbox_all" style="cursor: pointer;" />
