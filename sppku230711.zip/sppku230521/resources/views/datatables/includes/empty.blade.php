<tr>
    <td colspan="{{ collect($columns)->count() }}" class="p-4 text-xs text-center text-gray-800 bg-white">Hasil tidak ditemukan</td>
</tr>
