<footer class="main-footer">
    <div class="footer-left">
        © {{ date('Y') }} <div class="bullet"></div> Created with <i class="fad fa-heart" style="color: red;"></i> by <a href="https://elshobah.com/"
            target="blank">elshobah</a>  - Student of President University
    </div>
    <div class="footer-right">
        v0.0.1-beta
    </div>
</footer>
