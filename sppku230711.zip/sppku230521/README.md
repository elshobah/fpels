
# Sistem Informasi Pembayaran SPP
> *Mengelola pembayaran SPP dengan sistem informasi.*

Sistem Informasi Pembayaran SPP dibuat dengan Framework **Laravel 8**, **Package Laravel Module** dan **Livewire 2** dengan bahasa PHP dijalankan pada localhost laptop

Oleh: Muhammad Nurus Shobah
Mahasiswa President University Batch 2020
Sistem Informasi

